<?php
  
 $servidor="localhost";
          $usuario="root";
          $clave="";
          $basededatos="prueba";

     
  $enlace= mysqli_connect($servidor, $usuario, $clave, $basededatos);

   if(!$enlace){
                    echo"Error en la conexion con el servidor"; 

                }

  $email = $_GET["email"];
  $contra = $_GET["password"];

  $query = mysqli_query($enlace, "SELECT * FROM registro WHERE $email = '".$email."' and $contra = '".$contra."'   ");

      
?>